import { useRef } from "react";

const Hero = () => {
  const headingRef = useRef();
  const buttonRef = useRef();
  const formInputRef = useRef();
  const imageRef = useRef();
  const alertRef = useRef();

  const changeHeading = () => {
    headingRef.current.classList.toggle("text-success");
    headingRef.current.classList.toggle("text-danger");
    headingRef.current.innerText = "Welcome to the Hostel!";
  };

  const changeImage = () => {
    imageRef.current.src =
      "https://dummyjson.com/image/400x200/008080/ffffff?text=Hostel+Life";
    imageRef.current.setAttribute("height", "400");
    imageRef.current.setAttribute("width", "600");
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    alertRef.current.innerText = `Hello, ${
      formInputRef.current.value || "Guest"
    }! Welcome to the Hostel.`;
  };

  const toggleButtonColor = () => {
    buttonRef.current.style.backgroundColor =
      buttonRef.current.style.backgroundColor === "purple" ? "lavender" : "purple";
  };

  return (
    <div
      style={{
        backgroundColor: "#f7f4f9",
        color: "#6a0dad",
        padding: "20px",
        borderRadius: "10px",
        maxWidth: "600px",
        margin: "20px auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
      }}
    >
      <h1 ref={headingRef} className="text-success">
        Hello, Hostel Residents!
      </h1>
      <button ref={buttonRef} onClick={changeHeading} style={{ margin: "10px" }}>
        Change Heading
      </button>
      <div>
        <img
          ref={imageRef}
          src="https://dummyjson.com/image/400x200/282828"
          alt="Hostel Life"
          style={{ borderRadius: "10px", marginBottom: "15px" }}
        />
        <button onClick={changeImage} style={{ display: "block", margin: "10px auto" }}>
          Change Image
        </button>
      </div>
      <form
        onSubmit={handleFormSubmit}
        style={{ display: "flex", flexDirection: "column", alignItems: "center" }}
      >
        <input
          ref={formInputRef}
          type="text"
          placeholder="Type your name"
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ddd",
            marginBottom: "10px",
            width: "80%",
          }}
        />
        <button
          onClick={toggleButtonColor}
          style={{
            padding: "10px 20px",
            borderRadius: "5px",
            border: "none",
            backgroundColor: "purple",
            color: "#fff",
            cursor: "pointer",
          }}
          ref={buttonRef}
        >
          Submit
        </button>
      </form>
      <h3 ref={alertRef} style={{ textAlign: "center", marginTop: "20px" }}>
        Enter your name to see the welcome message.
      </h3>
    </div>
  );
};

export default Hero;
