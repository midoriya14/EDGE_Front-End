import React from "react";
import Hero from "./components/Hero";

const App = () => {
  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <Hero />
        </div>
      </div>
    </div>
  );
};

export default App;
