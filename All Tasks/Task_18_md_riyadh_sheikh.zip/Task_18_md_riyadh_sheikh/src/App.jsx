import React from 'react';
import HelloWorld from './components/HelloWorld';
import './index.css';

function App() {
    return (
        <div>
            <HelloWorld />
        </div>
    );
}

export default App;
