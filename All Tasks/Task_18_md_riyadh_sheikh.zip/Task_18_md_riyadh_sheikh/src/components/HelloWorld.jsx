import React from 'react';

function HelloWorld() {
    return (
        <div style={{ textAlign: 'center', padding: '20px', fontSize: '24px', color: '#ffffff' }}>
            Hello, World!
        </div>
    );
}

export default HelloWorld;
