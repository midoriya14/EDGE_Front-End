import React from 'react';

const HomePage = () => {
  return (
    <div style={{ textAlign: 'center', padding: '50px', backgroundColor: '#f7f4f9', color: '#6a0dad' }}>
      <h1>Welcome to the Main React Home Page</h1>
      <p>Explore the features of the Student Hostel Management System.</p>
    </div>
  );
};

export default HomePage;
