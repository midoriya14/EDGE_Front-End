import React from 'react';
import HomePage from './components/HomePage';
import './index.css';

function App() {
    return (
        <div>
            <HomePage />
        </div>
    );
}

export default App;
