import React from "react";

const Dropdown = () => {
  return (
    <div className="dropdown my-3">
      <button
        className="btn btn-secondary dropdown-toggle"
        type="button"
        id="dropdownMenuButton"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        Choose Hostel Options
      </button>
      <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <li>
          <a className="dropdown-item" href="#">
            Book Room
          </a>
        </li>
        <li>
          <a className="dropdown-item" href="#">
            View Facilities
          </a>
        </li>
        <li>
          <a className="dropdown-item" href="#">
            Hostel Rules
          </a>
        </li>
      </ul>
    </div>
  );
};

export default Dropdown;
