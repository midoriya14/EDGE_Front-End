import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Registration from "./components/Registration";
import Login from "./components/Login";

const App = () => {
  return (
    <Router>
      <Navbar />
      <div className="container my-5">
        <Routes>
          <Route path="/" element={<h1>Welcome to Student Hostel Management System</h1>} />
          <Route path="/register" element={<Registration />} />
          <Route path="/login" element={<Login />} />
          <Route path="/facilities" element={<h1>Hostel Facilities</h1>} />
          <Route path="/contact" element={<h1>Contact Us</h1>} />
        </Routes>
      </div>
      <Footer />
    </Router>
  );
};

export default App;
